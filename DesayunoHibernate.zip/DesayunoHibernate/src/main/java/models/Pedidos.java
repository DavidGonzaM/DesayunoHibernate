package models;

/*
* To change this license header, choose License Headers in Project Properties.
* To change this template file, choose Tools | Templates
* and open the template in the editor.
*/
import java.io.Serializable;
import java.sql.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 *
 * @author DavidGonzalezMartíne
 */
@Entity
@Table(name="Pedidos")
public class Pedidos implements Serializable {
    
    @Id
    @GeneratedValue(strategy= GenerationType.IDENTITY)
    int idP;
    @Column(name="nombre")
    String NombreP;
    @Column(name="fecha")
    Date fecha;
    @Column(name="entrega")
    int entrega;
    @Column(name="precio")
    Double precio;

    public Double getPrecio() {
        return precio;
    }

    public void setPrecio(Double precio) {
        this.precio = precio;
    }
    public Pedidos() {
    }


    public int getEntrega() {
        return entrega;
    }

    public void setEntrega(int entrega) {
        this.entrega = entrega;
    }

    public Pedidos(String NombreP, int idP, int entrega, Double precio) {
        this.NombreP = NombreP;
        this.idP = idP;

        this.entrega = entrega;
        this.precio = precio;
    }



    public String getNombreP() {
        return NombreP;
    }

    public void setNombreP(String NombreP) {
        this.NombreP = NombreP;
    }

    public int getIdP() {
        return idP;
    }

    public void setIdP(int idP) {
        this.idP = idP;
    }

    public Date getFecha() {
        return fecha;
    }

    public void setFecha(Date fecha) {
        this.fecha = fecha;
    }

    @Override
    public String toString() {
        return "Pedidos{" + "NombreP=" + NombreP + ", idP=" + idP + ", fecha=" + fecha + ", entrega=" + entrega + ", precio=" + precio + '}';
    }



    
    

    
}